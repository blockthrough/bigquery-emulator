# TS Greeter example

The following is an example on how to run the TS grpc server. Make sure that you have `Typescript` installed

you would need to run `npm run build` or simply use `npm install && tsc`

## How to run Server:

- `npm run server`

## How to run Client:

- `npm run client 3000`