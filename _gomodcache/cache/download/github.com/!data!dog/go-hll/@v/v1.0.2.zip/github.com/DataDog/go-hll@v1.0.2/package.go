// Package hll provides an HLL data type and operations that can be
// de/serialized by any code implementing the Aggregate Knowledge Storage Spec.
package hll
