//go:build !go1.17

package test
