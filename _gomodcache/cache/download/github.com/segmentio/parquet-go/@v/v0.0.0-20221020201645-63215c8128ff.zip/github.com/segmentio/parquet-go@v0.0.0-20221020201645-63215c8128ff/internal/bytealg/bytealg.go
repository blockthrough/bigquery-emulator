// Package bytealg contains optimized algorithms operating on byte slices.
package bytealg
